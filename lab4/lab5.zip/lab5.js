// number 1
function max(num1, num2) {
  if (num1 > num2) return num1;
  else if (num1 < num2) return num2;
  else return "they are Equal";
}

// number 2
function maxOfThree(num1, num2, num3) {
  let temp = num1;
  if (num2 > temp) temp = num2;
  else if (num3 > temp) temp = num3;
  return temp;
}

//  number 3
function isVowel(letter){
    switch(letter){
    case :'a','e','i','o','u'
    }}